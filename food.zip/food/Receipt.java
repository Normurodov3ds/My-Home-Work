package food;

public class Receipt {
    private int index = 0;
    private final Ingredient[] ingredients = new Ingredient[20];

    public void addIngredient(Ingredient ingredient) {
        if (ingredients[19] != null) {
            return;
        }
        ingredients[index++] = ingredient;
    }

    public Ingredient[] getIngredients() {
        return ingredients;
    }

    public void isEmpty() {
        if (ingredients.length == 0) {
            System.out.println("Retsept bo'sh!");
        } else {
            System.out.println("Retsept bo'sh emas!");
        }
    }

    public void isFull() {
        if (ingredients.length == 20) {
            System.out.println("Retsept to'lgan!");
        } else {
            System.out.println("Retsept hali to'lmagan!");
        }
    }

    public void showReceipt() {
        if (ingredients.length != 0) {
            System.out.println("Retseptda quyidagi mahsulotlar mavjud!");
            for (int i = 0; i < ingredients.length; i++) {
                if (ingredients[i] == null) {
                    break;
                }
                System.out.println((i + 1) + ") " + ingredients[i]);
            }
            System.out.println();
        }
    }
}
