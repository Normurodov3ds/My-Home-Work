package food;

public class Tuz extends Ingredient {
    public Tuz(double ingredientVolume) {
        super(ingredientVolume);
    }


}
