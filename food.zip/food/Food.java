package food;

public class Food {
    private final Receipt receipt;
    private final Ingredient[] ingredients = new Ingredient[20];
    private int index = 0;
    private boolean hasFood = false;

    public Food(Receipt receipt) {
        this.receipt = receipt;
    }

    public void add(Ingredient ingredient) {
        if (ingredients[19] != null) {
            return;
        }
        ingredients[index++] = ingredient;
        int counterFoodIngredients = 0;
        int counterReceiptIngredients = 0;
        for (Ingredient ingredient1 : ingredients) {
            if (ingredient1 != null) {
                counterFoodIngredients++;
            }
        }
        for (Ingredient ingredient1 : receipt.getIngredients()) {
            if (ingredient1 != null) {
                counterReceiptIngredients++;
            }
        }
        if (counterFoodIngredients == counterReceiptIngredients) {
            checkIngredients();
        }
    }

    private void checkIngredients() {
        parentIngredientFor:
        for (Ingredient ingredient1 : ingredients) {
            for (Ingredient receiptIngredient : receipt.getIngredients()) {
                if (ingredient1 == null) {
                    continue parentIngredientFor;
                }
                if (receiptIngredient == null) {
                    continue;
                }
                if (ingredient1.getClass().getName().equals(receiptIngredient.getClass().getName())) {
                    if (ingredient1.getIngredientVolume() < receiptIngredient.getIngredientVolume()) {
                        hasFood = false;
                        System.out.println(ingredient1.getClass().getName() + " mahsulotini grami kam qo'shish kerak!");
                        System.out.println();
                        return;
                    } else {
                        hasFood = true;
                    }
                }
            }
        }
    }

    public void getReceipt() {
        receipt.showReceipt();
    }


    public void showIngredients() {
        if (ingredients.length != 0) {
            System.out.println("Foodga quyidagalarni qo'shdingiz!");
            for (int i = 0; i < ingredients.length; i++) {
                if (ingredients[i] == null) {
                    break;
                }
                System.out.println((i + 1) + ") " + ingredients[i]);
            }
            System.out.println();
        }
    }

    public boolean hasFood() {
        return hasFood;
    }
}
