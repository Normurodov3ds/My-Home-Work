package food;

public class Zira extends Ingredient{
    public Zira(double ingredientVolume) {
        super(ingredientVolume);
    }
}
