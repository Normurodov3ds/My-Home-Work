package food;

public class Piyoz extends Ingredient{
    public Piyoz(double ingredientVolume) {
        super(ingredientVolume);
    }
}
