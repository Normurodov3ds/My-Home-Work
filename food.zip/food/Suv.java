package food;

public class Suv extends Ingredient{
    public Suv(double ingredientVolume) {
        super(ingredientVolume);
    }
}
