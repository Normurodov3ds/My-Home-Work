package food;

public class Main {
    public static void main(String[] args) {
        Tuz tuz = new Tuz(100);
        Gosht gosht = new Gosht(300);
        Piyoz piyoz = new Piyoz(75);
        Suv suv = new Suv(1000);
        Zira zira = new Zira(50);
        Guruch guruch = new Guruch(400);

        Receipt receipt = new Receipt();
        receipt.addIngredient(piyoz);
        receipt.addIngredient(gosht);
        receipt.addIngredient(zira);
        receipt.addIngredient(tuz);
        receipt.addIngredient(guruch);
        receipt.addIngredient(suv);

        receipt.showReceipt();

        Food food = new Food(receipt);
        food.add(new Tuz(110));
        food.add(gosht);
        food.add(piyoz);
        food.add(zira);
        food.add(suv);
        food.add(guruch);
        food.showIngredients();
        System.out.println(food.hasFood());
    }
}
