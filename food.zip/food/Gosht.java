package food;

public class Gosht extends Ingredient{
    public Gosht(double ingredientVolume) {
        super(ingredientVolume);
    }
}
