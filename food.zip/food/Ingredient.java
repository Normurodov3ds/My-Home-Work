package food;

public abstract class Ingredient {
    private double ingredientVolume;

    public Ingredient(double ingredientVolume) {
        this.ingredientVolume = ingredientVolume;
    }

    public double getIngredientVolume() {
        return ingredientVolume;
    }

    public void setIngredientVolume(double ingredientVolume) {
        this.ingredientVolume = ingredientVolume;
    }

    @Override
    public String toString() {
        return this.getClass().getName() + " - " + +ingredientVolume + " gram";
    }
}
