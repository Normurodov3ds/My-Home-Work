package food;

public class Guruch extends Ingredient{
    public Guruch(double ingredientVolume) {
        super(ingredientVolume);
    }
}
